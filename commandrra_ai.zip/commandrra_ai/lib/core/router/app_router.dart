import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/storage_provider.dart';
import '../../screens/onboarding/onboarding_screen.dart';
import '../../screens/chat/home_shell.dart';
import '../../screens/skills/skills_screen.dart';
import '../../screens/connectors/connectors_screen.dart';
import '../../screens/settings/settings_screen.dart';
import '../../screens/plans/plans_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  final storage = ref.read(storageServiceProvider);

  return GoRouter(
    initialLocation: storage.hasOnboarded ? '/' : '/onboarding',
    routes: [
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/',
        builder: (context, state) => const HomeShell(),
      ),
      GoRoute(
        path: '/skills',
        builder: (context, state) => const SkillsScreen(),
      ),
      GoRoute(
        path: '/connectors',
        builder: (context, state) => const ConnectorsScreen(),
      ),
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/plans',
        builder: (context, state) => const PlansScreen(),
      ),
    ],
  );
});
