/// Central place for identity, copy, and business constants.
/// Swap MODEL_NAME or plan limits here without hunting through the app.
class AppConstants {
  AppConstants._();

  static const String appName = 'Commandrra AI';
  static const String modelName = 'commandrra 2.1';
  static const String modelTagline = 'Chat, Search & Code — one model.';

  static const String modelDescription =
      'commandrra 2.1 answers like a conversation partner, researches like a '
      'search engine with cited sources, and writes code like a senior '
      'engineer — switch modes without switching apps.';
}

/// Token allowance per plan, reset monthly. These are the numbers shown to
/// the user in the usage meter and the plan comparison screen.
class PlanLimits {
  PlanLimits._();

  static const int freeMonthlyTokens = 50000;
  static const int proMonthlyTokens = 1000000;
  static const int teamMonthlyTokens = 5000000;

  static const int freeDailyMessages = 20;
  static const int proDailyMessages = -1; // -1 = unlimited
  static const int teamDailyMessages = -1;

  static const double proPriceMonthly = 9.99;
  static const double teamPriceMonthly = 24.99;
}
