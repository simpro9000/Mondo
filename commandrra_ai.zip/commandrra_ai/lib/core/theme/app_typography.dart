import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Two-voice type system:
/// - Inter for interface & conversational text (the "human" voice)
/// - JetBrains Mono for commands, code, tokens & system chrome
///   (the "machine" voice) — reinforces the commandrra identity.
class AppTypography {
  AppTypography._();

  static TextStyle get _interBase => GoogleFonts.inter(color: AppColors.textPrimary);
  static TextStyle get _monoBase => GoogleFonts.jetBrainsMono(color: AppColors.textPrimary);

  // Display / headings
  static TextStyle displayLg = _interBase.copyWith(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    letterSpacing: -0.6,
    height: 1.15,
  );

  static TextStyle displayMd = _interBase.copyWith(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    letterSpacing: -0.4,
    height: 1.2,
  );

  static TextStyle headingLg = _interBase.copyWith(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    letterSpacing: -0.2,
  );

  static TextStyle headingMd = _interBase.copyWith(
    fontSize: 17,
    fontWeight: FontWeight.w600,
  );

  static TextStyle headingSm = _interBase.copyWith(
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  // Body
  static TextStyle bodyLg = _interBase.copyWith(fontSize: 16, height: 1.5, fontWeight: FontWeight.w400);
  static TextStyle bodyMd = _interBase.copyWith(fontSize: 14.5, height: 1.5, fontWeight: FontWeight.w400);
  static TextStyle bodySm = _interBase.copyWith(fontSize: 13, height: 1.45, fontWeight: FontWeight.w400);

  // Secondary text
  static TextStyle caption = _interBase.copyWith(
    fontSize: 12,
    fontWeight: FontWeight.w500,
    color: AppColors.textSecondary,
  );

  static TextStyle overline = _monoBase.copyWith(
    fontSize: 11,
    fontWeight: FontWeight.w500,
    letterSpacing: 1.2,
    color: AppColors.textTertiary,
  );

  // Mono / command / code voice
  static TextStyle mono = _monoBase.copyWith(fontSize: 13.5, height: 1.55, fontWeight: FontWeight.w400);
  static TextStyle monoSm = _monoBase.copyWith(fontSize: 12, height: 1.5, fontWeight: FontWeight.w400);
  static TextStyle monoPrompt = _monoBase.copyWith(
    fontSize: 15,
    fontWeight: FontWeight.w500,
    color: AppColors.amber,
  );

  // Buttons
  static TextStyle button = _interBase.copyWith(fontSize: 14.5, fontWeight: FontWeight.w600);
  static TextStyle buttonSm = _interBase.copyWith(fontSize: 13, fontWeight: FontWeight.w600);
}
