import 'package:flutter/material.dart';

/// Commandrra AI color system.
///
/// Design language: a "terminal echo" identity — the app's visual world is
/// built around the idea of a command prompt that reshapes itself for each
/// mode (chat / search / code). The palette stays disciplined (ink + slate)
/// and spends its color budget on two signal accents that map to meaning:
/// amber for the assistant/command voice, cyan for search & code contexts.
class AppColors {
  AppColors._();

  // Base surfaces — "Deep Ink"
  static const Color bgPrimary = Color(0xFF0B0E14);
  static const Color bgSecondary = Color(0xFF11151D);
  static const Color bgElevated = Color(0xFF171C26);
  static const Color bgOverlay = Color(0xFF1F2530);
  static const Color border = Color(0xFF262C38);
  static const Color borderSubtle = Color(0xFF1B202B);

  // Text — "Cool Slate"
  static const Color textPrimary = Color(0xFFF5F6F8);
  static const Color textSecondary = Color(0xFFA6ADBB);
  static const Color textTertiary = Color(0xFF6B7280);
  static const Color textDisabled = Color(0xFF454B58);

  // Signal accents
  static const Color amber = Color(0xFFFFB454); // command / assistant voice
  static const Color amberDim = Color(0xFF8A6530);
  static const Color cyan = Color(0xFF4FD1C5); // search & code contexts
  static const Color cyanDim = Color(0xFF2B6E67);

  // Functional
  static const Color success = Color(0xFF4ADE80);
  static const Color warning = Color(0xFFFACC15);
  static const Color danger = Color(0xFFF87171);
  static const Color info = Color(0xFF60A5FA);

  // Mode-specific gradients (used on the transforming command bar)
  static const List<Color> chatGradient = [Color(0xFFFFB454), Color(0xFFFF8A5B)];
  static const List<Color> searchGradient = [Color(0xFF4FD1C5), Color(0xFF3B82F6)];
  static const List<Color> codeGradient = [Color(0xFF8B5CF6), Color(0xFF4FD1C5)];

  // Plan tier accents
  static const Color planFree = Color(0xFF6B7280);
  static const Color planPro = Color(0xFFFFB454);
  static const Color planTeam = Color(0xFF4FD1C5);

  static const Color scrim = Color(0xB3000000);
}
