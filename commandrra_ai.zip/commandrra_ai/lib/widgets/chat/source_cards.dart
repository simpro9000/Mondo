import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/message.dart';

class SourceCards extends StatelessWidget {
  final List<SourceRef> sources;

  const SourceCards({super.key, required this.sources});

  @override
  Widget build(BuildContext context) {
    if (sources.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const Icon(LucideIcons.link, size: 14, color: AppColors.cyan),
            const SizedBox(width: 6),
            Text('المصادر (${sources.length})', style: AppTypography.caption.copyWith(color: AppColors.cyan)),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 92,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: sources.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final source = sources[i];
              return _SourceCard(source: source, index: i + 1);
            },
          ),
        ),
      ],
    );
  }
}

class _SourceCard extends StatelessWidget {
  final SourceRef source;
  final int index;

  const _SourceCard({required this.source, required this.index});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => launchUrl(Uri.parse(source.url)),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 210,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.bgElevated,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.borderSubtle),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 18,
                  height: 18,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.cyanDim,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text(
                    '$index',
                    style: AppTypography.caption.copyWith(fontSize: 10, color: AppColors.cyan),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    source.domain,
                    style: AppTypography.caption,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              source.title,
              style: AppTypography.bodySm.copyWith(fontWeight: FontWeight.w600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
