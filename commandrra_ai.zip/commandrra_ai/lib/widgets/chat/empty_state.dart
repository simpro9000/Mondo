import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../providers/chat_controller.dart';
import '../../providers/skills_provider.dart';
import '../common/icon_resolver.dart';

class ChatEmptyState extends ConsumerWidget {
  const ChatEmptyState({super.key});

  static const Map<AssistantMode, List<String>> _suggestions = {
    AssistantMode.chat: [
      'اشرح ليا الفرق بين REST و GraphQL',
      'اكتب ليا خطة تمرين لمدة أسبوع',
      'ساعدني نصيغ رسالة اعتذار لعميل',
    ],
    AssistantMode.search: [
      'آخر أخبار الذكاء الاصطناعي هاد الأسبوع',
      'قارن ليا بين Flutter و React Native',
      'شنو هي أحسن الممارسات فـ SEO دابا',
    ],
    AssistantMode.code: [
      'صايب ليا REST API بسيط بـ FastAPI',
      'صحح هاد الكود اللي فيه bug',
      'اشرح ليا كيفاش تخدم async/await',
    ],
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(activeModeProvider);
    final enabledSkills = ref.watch(skillsProvider).where((s) => s.enabled).take(4).toList();
    final suggestions = _suggestions[mode]!;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
      children: [
        _Hero(mode: mode),
        const SizedBox(height: 28),
        Text('جرّب واحد من هادو', style: AppTypography.caption),
        const SizedBox(height: 10),
        ...suggestions.map((s) => _SuggestionRow(text: s, mode: mode)),
        if (enabledSkills.isNotEmpty) ...[
          const SizedBox(height: 20),
          Text('المهارات النشطة ديالك', style: AppTypography.caption),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: enabledSkills.map((skill) {
              return InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => ref.read(activeSkillIdProvider.notifier).state = skill.id,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColors.bgElevated,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.borderSubtle),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(resolveIcon(skill.icon), size: 15, color: AppColors.amber),
                      const SizedBox(width: 8),
                      Text(skill.name, style: AppTypography.bodySm),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }
}

class _Hero extends StatelessWidget {
  final AssistantMode mode;

  const _Hero({required this.mode});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: _gradientFor(mode)),
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Icon(LucideIcons.terminal, color: AppColors.bgPrimary, size: 26),
        ),
        const SizedBox(height: 16),
        Text(AppConstants.modelName, style: AppTypography.displayMd),
        const SizedBox(height: 6),
        Text(
          AppConstants.modelDescription,
          style: AppTypography.bodyMd.copyWith(color: AppColors.textSecondary),
        ),
      ],
    );
  }

  List<Color> _gradientFor(AssistantMode mode) => switch (mode) {
        AssistantMode.chat => AppColors.chatGradient,
        AssistantMode.search => AppColors.searchGradient,
        AssistantMode.code => AppColors.codeGradient,
      };
}

class _SuggestionRow extends ConsumerWidget {
  final String text;
  final AssistantMode mode;

  const _SuggestionRow({required this.text, required this.mode});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => ref.read(chatControllerProvider).sendMessage(text: text),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.bgElevated,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: Row(
            children: [
              Icon(
                mode == AssistantMode.search
                    ? LucideIcons.search
                    : mode == AssistantMode.code
                        ? LucideIcons.terminal
                        : LucideIcons.messageCircle,
                size: 15,
                color: AppColors.textTertiary,
              ),
              const SizedBox(width: 10),
              Expanded(child: Text(text, style: AppTypography.bodySm)),
            ],
          ),
        ),
      ),
    );
  }
}
