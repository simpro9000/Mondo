import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import 'code_block.dart';

/// Splits raw assistant text on fenced code blocks (```lang ... ```) and
/// renders plain segments as Markdown while code segments get full syntax
/// highlighting via [CodeBlock]. This keeps the mock/real API response
/// format simple (plain text with fences) while still producing a rich UI.
class AssistantMarkdownBody extends StatelessWidget {
  final String content;

  const AssistantMarkdownBody({super.key, required this.content});

  List<_Segment> _parse(String text) {
    final segments = <_Segment>[];
    final pattern = RegExp(r'```(\w*)\n([\s\S]*?)```');
    int lastEnd = 0;

    for (final match in pattern.allMatches(text)) {
      if (match.start > lastEnd) {
        segments.add(_Segment.text(text.substring(lastEnd, match.start)));
      }
      final lang = match.group(1)?.isNotEmpty == true ? match.group(1)! : 'plaintext';
      segments.add(_Segment.code(match.group(2) ?? '', lang));
      lastEnd = match.end;
    }
    if (lastEnd < text.length) {
      segments.add(_Segment.text(text.substring(lastEnd)));
    }
    return segments;
  }

  @override
  Widget build(BuildContext context) {
    final segments = _parse(content);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final segment in segments)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: segment.isCode
                ? CodeBlock(code: segment.text.trimRight(), language: segment.language)
                : MarkdownBody(
                    data: segment.text,
                    selectable: true,
                    onTapLink: (text, href, title) {
                      if (href != null) launchUrl(Uri.parse(href));
                    },
                    styleSheet: MarkdownStyleSheet(
                      p: AppTypography.bodyMd,
                      strong: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.w700),
                      em: AppTypography.bodyMd.copyWith(fontStyle: FontStyle.italic),
                      code: AppTypography.monoSm.copyWith(
                        backgroundColor: AppColors.bgOverlay,
                        color: AppColors.cyan,
                      ),
                      codeblockDecoration: BoxDecoration(
                        color: AppColors.bgOverlay,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      listBullet: AppTypography.bodyMd,
                      h1: AppTypography.headingLg,
                      h2: AppTypography.headingMd,
                      h3: AppTypography.headingSm,
                      a: AppTypography.bodyMd.copyWith(
                        color: AppColors.cyan,
                        decoration: TextDecoration.underline,
                      ),
                      blockquoteDecoration: const BoxDecoration(
                        border: Border(left: BorderSide(color: AppColors.amber, width: 3)),
                      ),
                      blockquotePadding: const EdgeInsets.only(right: 12),
                    ),
                  ),
          ),
      ],
    );
  }
}

class _Segment {
  final bool isCode;
  final String text;
  final String language;

  _Segment.text(this.text) : isCode = false, language = '';
  _Segment.code(this.text, this.language) : isCode = true;
}
