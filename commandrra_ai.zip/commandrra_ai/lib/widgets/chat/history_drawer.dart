import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/conversation.dart';
import '../../providers/chat_controller.dart';
import '../../providers/conversations_provider.dart';

class HistoryDrawer extends ConsumerWidget {
  const HistoryDrawer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final conversations = ref.watch(conversationsProvider);
    final activeId = ref.watch(activeConversationIdProvider);
    final pinned = conversations.where((c) => c.pinned).toList();
    final others = conversations.where((c) => !c.pinned).toList();

    return Drawer(
      backgroundColor: AppColors.bgSecondary,
      width: MediaQuery.of(context).size.width * 0.84,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 12, 8),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: AppColors.amber,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(LucideIcons.terminal, size: 16, color: AppColors.bgPrimary),
                  ),
                  const SizedBox(width: 10),
                  Text(AppConstants.appName, style: AppTypography.headingSm),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(LucideIcons.x, size: 20),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    ref.read(chatControllerProvider).startNewConversation();
                    Navigator.pop(context);
                  },
                  icon: const Icon(LucideIcons.plus, size: 16),
                  label: const Text('محادثة جديدة'),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                children: [
                  _NavItem(
                    icon: LucideIcons.sparkles,
                    label: 'المهارات',
                    onTap: () {
                      Navigator.pop(context);
                      context.push('/skills');
                    },
                  ),
                  _NavItem(
                    icon: LucideIcons.plug,
                    label: 'الموصلات',
                    onTap: () {
                      Navigator.pop(context);
                      context.push('/connectors');
                    },
                  ),
                ],
              ),
            ),
            const Divider(height: 20),
            Expanded(
              child: conversations.isEmpty
                  ? Center(
                      child: Text(
                        'لا توجد محادثات بعد',
                        style: AppTypography.bodySm.copyWith(color: AppColors.textTertiary),
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      children: [
                        if (pinned.isNotEmpty) ...[
                          _SectionLabel('مثبتة'),
                          ...pinned.map((c) => _ConversationTile(
                                conversation: c,
                                isActive: c.id == activeId,
                              )),
                          const SizedBox(height: 8),
                        ],
                        if (others.isNotEmpty) ...[
                          _SectionLabel('الكل'),
                          ...others.map((c) => _ConversationTile(
                                conversation: c,
                                isActive: c.id == activeId,
                              )),
                        ],
                      ],
                    ),
            ),
            const Divider(height: 1),
            _NavItem(
              icon: LucideIcons.settings,
              label: 'الإعدادات',
              onTap: () {
                Navigator.pop(context);
                context.push('/settings');
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel(this.label);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
      child: Text(label, style: AppTypography.overline),
    );
  }
}

class _ConversationTile extends ConsumerWidget {
  final Conversation conversation;
  final bool isActive;

  const _ConversationTile({required this.conversation, required this.isActive});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: isActive ? AppColors.bgElevated : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        dense: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          conversation.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.bodySm,
        ),
        onTap: () {
          ref.read(activeConversationIdProvider.notifier).state = conversation.id;
          ref.read(activeModeProvider.notifier).state = conversation.lastMode;
          Navigator.pop(context);
        },
        trailing: PopupMenuButton<String>(
          icon: const Icon(LucideIcons.moreHorizontal, size: 16, color: AppColors.textTertiary),
          color: AppColors.bgOverlay,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          onSelected: (value) {
            final notifier = ref.read(conversationsProvider.notifier);
            if (value == 'pin') notifier.togglePin(conversation.id);
            if (value == 'delete') {
              notifier.deleteConversation(conversation.id);
              if (isActive) ref.read(activeConversationIdProvider.notifier).state = null;
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'pin',
              child: Text(conversation.pinned ? 'إلغاء التثبيت' : 'تثبيت', style: AppTypography.bodySm),
            ),
            PopupMenuItem(
              value: 'delete',
              child: Text('حذف', style: AppTypography.bodySm.copyWith(color: AppColors.danger)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _NavItem({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      leading: Icon(icon, size: 19),
      title: Text(label, style: AppTypography.bodySm),
      onTap: onTap,
    );
  }
}
