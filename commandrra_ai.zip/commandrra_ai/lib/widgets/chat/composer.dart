import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/message.dart';
import '../../models/skill.dart';
import '../../providers/chat_controller.dart';
import '../../providers/skills_provider.dart';
import 'attachment_sheet.dart';
import 'attachment_chip.dart';

class Composer extends ConsumerStatefulWidget {
  const Composer({super.key});

  @override
  ConsumerState<Composer> createState() => _ComposerState();
}

class _ComposerState extends ConsumerState<Composer> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  final List<Attachment> _pendingAttachments = [];

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _handleSend() async {
    final text = _controller.text.trim();
    if (text.isEmpty && _pendingAttachments.isEmpty) return;

    final attachments = List<Attachment>.from(_pendingAttachments);
    _controller.clear();
    setState(() => _pendingAttachments.clear());

    try {
      await ref.read(chatControllerProvider).sendMessage(text: text, attachments: attachments);
    } on TokenLimitException {
      _showLimitDialog(
        title: 'وصلت لحد التوكنز',
        message: 'استهلكت كل التوكنز المتاحة فخطتك الحالية. رقّي خطتك باش تكمل.',
      );
    } on DailyLimitException {
      _showLimitDialog(
        title: 'وصلت للحد اليومي',
        message: 'استعملتي عدد الرسائل المسموح بيه اليوم. جرب غدا أو رقّي خطتك.',
      );
    }
  }

  void _showLimitDialog({required String title, required String message}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title, style: AppTypography.headingMd),
        content: Text(message, style: AppTypography.bodyMd.copyWith(color: AppColors.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              context.push('/plans');
            },
            child: const Text('عرض الخطط'),
          ),
        ],
      ),
    );
  }

  Future<void> _openAttachmentSheet() async {
    final result = await showAttachmentSheet(context);
    if (result != null) {
      setState(() => _pendingAttachments.add(result));
    }
  }

  @override
  Widget build(BuildContext context) {
    final mode = ref.watch(activeModeProvider);
    final isResponding = ref.watch(isRespondingProvider);
    final activeSkillId = ref.watch(activeSkillIdProvider);
    final skills = ref.watch(skillsProvider);

    Skill? activeSkill;
    if (activeSkillId != null) {
      for (final s in skills) {
        if (s.id == activeSkillId) {
          activeSkill = s;
          break;
        }
      }
    }

    return Container(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 10,
        bottom: MediaQuery.of(context).padding.bottom + 10,
      ),
      decoration: const BoxDecoration(
        color: AppColors.bgPrimary,
        border: Border(top: BorderSide(color: AppColors.borderSubtle)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (activeSkill != null)
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Chip(
                  avatar: const Icon(LucideIcons.sparkles, size: 14, color: AppColors.amber),
                  label: Text('مهارة: ${activeSkill.name}', style: AppTypography.caption),
                  onDeleted: () => ref.read(activeSkillIdProvider.notifier).state = null,
                  deleteIcon: const Icon(LucideIcons.x, size: 14),
                ),
              ),
            ),
          if (_pendingAttachments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _pendingAttachments
                    .map((a) => AttachmentChip(
                          attachment: a,
                          onRemove: () => setState(() => _pendingAttachments.remove(a)),
                        ))
                    .toList(),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              color: AppColors.bgElevated,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _focusNode.hasFocus ? _accentFor(mode) : AppColors.border,
                width: _focusNode.hasFocus ? 1.4 : 1,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: isResponding ? null : _openAttachmentSheet,
                  icon: const Icon(LucideIcons.plus, size: 20),
                  color: AppColors.textSecondary,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      minLines: 1,
                      maxLines: 6,
                      textInputAction: TextInputAction.newline,
                      style: mode == AssistantMode.code ? AppTypography.mono : AppTypography.bodyMd,
                      decoration: InputDecoration(
                        hintText: mode.hint,
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(6),
                  child: _SendButton(
                    isResponding: isResponding,
                    accent: _accentFor(mode),
                    onSend: _handleSend,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _accentFor(AssistantMode mode) => switch (mode) {
        AssistantMode.chat => AppColors.amber,
        AssistantMode.search => AppColors.cyan,
        AssistantMode.code => const Color(0xFF8B5CF6),
      };
}

class _SendButton extends StatelessWidget {
  final bool isResponding;
  final Color accent;
  final VoidCallback onSend;

  const _SendButton({
    required this.isResponding,
    required this.accent,
    required this.onSend,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isResponding ? null : onSend,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: isResponding ? AppColors.bgOverlay : accent,
          shape: BoxShape.circle,
        ),
        child: Icon(
          isResponding ? LucideIcons.square : LucideIcons.arrowUp,
          size: 18,
          color: isResponding ? AppColors.textSecondary : AppColors.bgPrimary,
        ),
      ),
    );
  }
}
