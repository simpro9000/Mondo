import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/message.dart';
import 'markdown_body.dart';
import 'source_cards.dart';
import 'typing_indicator.dart';

class MessageBubble extends StatelessWidget {
  final ChatMessage message;

  const MessageBubble({super.key, required this.message});

  Color get _accent => switch (message.mode) {
        AssistantMode.chat => AppColors.amber,
        AssistantMode.search => AppColors.cyan,
        AssistantMode.code => const Color(0xFF8B5CF6),
      };

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: message.isUser ? _buildUserBubble(context) : _buildAssistantBubble(context),
    );
  }

  Widget _buildUserBubble(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        if (message.attachments.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Wrap(
              spacing: 6,
              alignment: WrapAlignment.end,
              children: message.attachments
                  .map((a) => Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.bgOverlay,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              a.type == AttachmentType.image ? LucideIcons.image : LucideIcons.fileText,
                              size: 13,
                              color: AppColors.textSecondary,
                            ),
                            const SizedBox(width: 5),
                            Text(a.name, style: AppTypography.caption),
                          ],
                        ),
                      ))
                  .toList(),
            ),
          ),
        Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.bgElevated,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(18),
              topRight: Radius.circular(18),
              bottomLeft: Radius.circular(18),
              bottomRight: Radius.circular(4),
            ),
          ),
          child: Text(message.content, style: AppTypography.bodyMd),
        ),
      ],
    );
  }

  Widget _buildAssistantBubble(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(color: _accent, borderRadius: BorderRadius.circular(7)),
              child: const Icon(LucideIcons.terminal, size: 13, color: AppColors.bgPrimary),
            ),
            const SizedBox(width: 8),
            Text('commandrra', style: AppTypography.caption.copyWith(color: _accent)),
            if (message.skillUsed != null) ...[
              const SizedBox(width: 6),
              Icon(LucideIcons.sparkles, size: 11, color: AppColors.textTertiary),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.only(right: 32),
          child: message.content.isEmpty && message.isStreaming
              ? TypingIndicator(color: _accent)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    AssistantMarkdownBody(content: message.content),
                    if (message.sources.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      SourceCards(sources: message.sources),
                    ],
                    if (message.status == MessageStatus.error)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Row(
                          children: [
                            const Icon(LucideIcons.alertTriangle, size: 13, color: AppColors.danger),
                            const SizedBox(width: 6),
                            Text(
                              'حدث خطأ',
                              style: AppTypography.caption.copyWith(color: AppColors.danger),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
      ],
    );
  }
}
