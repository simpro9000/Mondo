import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';

/// A syntax-highlighted code block with a header showing the language and
/// a copy-to-clipboard action — the visual signature of "code mode".
class CodeBlock extends StatefulWidget {
  final String code;
  final String language;

  const CodeBlock({super.key, required this.code, this.language = 'dart'});

  @override
  State<CodeBlock> createState() => _CodeBlockState();
}

class _CodeBlockState extends State<CodeBlock> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    setState(() => _copied = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF11151D),
          border: Border.all(color: AppColors.borderSubtle),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: const BoxDecoration(
                color: AppColors.bgOverlay,
                border: Border(bottom: BorderSide(color: AppColors.borderSubtle)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(widget.language, style: AppTypography.monoSm.copyWith(color: AppColors.cyan)),
                  InkWell(
                    onTap: _copy,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Row(
                        children: [
                          Icon(
                            _copied ? LucideIcons.check : LucideIcons.copy,
                            size: 13,
                            color: _copied ? AppColors.success : AppColors.textTertiary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _copied ? 'تم النسخ' : 'نسخ',
                            style: AppTypography.caption.copyWith(
                              color: _copied ? AppColors.success : AppColors.textTertiary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(14),
              child: HighlightView(
                widget.code,
                language: widget.language,
                theme: atomOneDarkTheme,
                textStyle: AppTypography.mono,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
