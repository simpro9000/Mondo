import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/message.dart';

/// Presents attachment source options and returns a populated [Attachment]
/// once the user picks something, or null if they dismiss the sheet.
Future<Attachment?> showAttachmentSheet(BuildContext context) {
  return showModalBottomSheet<Attachment?>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (context) => const _AttachmentSheet(),
  );
}

class _AttachmentSheet extends StatelessWidget {
  const _AttachmentSheet();

  Future<void> _pickImage(BuildContext context, ImageSource source) async {
    try {
      final picker = ImagePicker();
      final file = await picker.pickImage(source: source, imageQuality: 85);
      if (file != null && context.mounted) {
        Navigator.pop(
          context,
          Attachment(type: AttachmentType.image, name: file.name, localPath: file.path),
        );
      }
    } catch (_) {
      if (context.mounted) Navigator.pop(context);
    }
  }

  Future<void> _pickFile(BuildContext context) async {
    try {
      final result = await FilePicker.platform.pickFiles();
      final file = result?.files.first;
      if (file != null && context.mounted) {
        Navigator.pop(
          context,
          Attachment(
            type: AttachmentType.file,
            name: file.name,
            localPath: file.path,
            sizeBytes: file.size,
          ),
        );
      }
    } catch (_) {
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: 12,
        left: 16,
        right: 16,
        bottom: MediaQuery.of(context).padding.bottom + 16,
      ),
      decoration: const BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),
          Text('إضافة مرفق', style: AppTypography.headingMd),
          const SizedBox(height: 20),
          _OptionTile(
            icon: LucideIcons.camera,
            label: 'التقاط صورة',
            onTap: () => _pickImage(context, ImageSource.camera),
          ),
          _OptionTile(
            icon: LucideIcons.image,
            label: 'اختيار من المعرض',
            onTap: () => _pickImage(context, ImageSource.gallery),
          ),
          _OptionTile(
            icon: LucideIcons.fileUp,
            label: 'رفع ملف',
            onTap: () => _pickFile(context),
          ),
        ],
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _OptionTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: AppColors.bgOverlay,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, size: 20, color: AppColors.amber),
      ),
      title: Text(label, style: AppTypography.bodyMd),
      trailing: const Icon(LucideIcons.chevronLeft, size: 18, color: AppColors.textTertiary),
    );
  }
}
