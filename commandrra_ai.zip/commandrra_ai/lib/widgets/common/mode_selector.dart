import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../providers/chat_controller.dart';

/// The app's signature element: a segmented "prompt" selector styled like a
/// terminal mode switch. Each mode carries its own accent gradient and
/// icon; the active segment gets a soft glow using that gradient, echoing
/// the idea of a command prompt reconfiguring itself.
class ModeSelector extends ConsumerWidget {
  const ModeSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeMode = ref.watch(activeModeProvider);

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: AssistantMode.values.map((mode) {
          final isActive = mode == activeMode;
          return Expanded(
            child: GestureDetector(
              onTap: () => ref.read(activeModeProvider.notifier).state = mode,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(11),
                  gradient: isActive
                      ? LinearGradient(colors: _gradientFor(mode))
                      : null,
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: _gradientFor(mode).first.withValues(alpha: 0.35),
                            blurRadius: 14,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _iconFor(mode),
                      size: 16,
                      color: isActive ? AppColors.bgPrimary : AppColors.textTertiary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      mode.label,
                      style: AppTypography.buttonSm.copyWith(
                        color: isActive ? AppColors.bgPrimary : AppColors.textTertiary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  List<Color> _gradientFor(AssistantMode mode) => switch (mode) {
        AssistantMode.chat => AppColors.chatGradient,
        AssistantMode.search => AppColors.searchGradient,
        AssistantMode.code => AppColors.codeGradient,
      };

  IconData _iconFor(AssistantMode mode) => switch (mode) {
        AssistantMode.chat => LucideIcons.messageCircle,
        AssistantMode.search => LucideIcons.search,
        AssistantMode.code => LucideIcons.terminal,
      };
}
