import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../providers/usage_provider.dart';

/// Compact pill showing remaining token budget. Tapping opens the plans
/// screen — this is the app's primary upsell surface, so it stays visible
/// but never blocking.
class UsageMeterPill extends ConsumerWidget {
  const UsageMeterPill({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usage = ref.watch(usageProvider);
    final color = usage.isNearLimit ? AppColors.danger : AppColors.amber;

    return InkWell(
      onTap: () => context.push('/plans'),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.bgElevated,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                value: usage.tokenUsageRatio,
                strokeWidth: 2.2,
                backgroundColor: AppColors.border,
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
            const SizedBox(width: 6),
            Text(
              _formatTokens(usage.tokensRemaining),
              style: AppTypography.monoSm.copyWith(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTokens(int tokens) {
    if (tokens >= 1000000) return '${(tokens / 1000000).toStringAsFixed(1)}M';
    if (tokens >= 1000) return '${(tokens / 1000).toStringAsFixed(0)}K';
    return '$tokens';
  }
}

/// Full usage bar with label — used in Settings and the Plans screen.
class UsageMeterBar extends ConsumerWidget {
  const UsageMeterBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usage = ref.watch(usageProvider);
    final color = usage.isNearLimit ? AppColors.danger : AppColors.amber;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(LucideIcons.zap, size: 16, color: AppColors.amber),
                  const SizedBox(width: 6),
                  Text('استخدام التوكنز', style: AppTypography.headingSm),
                ],
              ),
              Text(
                '${usage.plan.tier.label}',
                style: AppTypography.caption.copyWith(color: AppColors.amber),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: usage.tokenUsageRatio,
              minHeight: 8,
              backgroundColor: AppColors.border,
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${_format(usage.tokensUsed)} / ${_format(usage.plan.monthlyTokens)} توكن',
                style: AppTypography.monoSm.copyWith(color: AppColors.textSecondary),
              ),
              if (usage.hasDailyMessageLimit)
                Text(
                  '${usage.dailyMessagesRemaining} رسالة متبقية اليوم',
                  style: AppTypography.caption,
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _format(int tokens) {
    if (tokens >= 1000000) return '${(tokens / 1000000).toStringAsFixed(1)}M';
    if (tokens >= 1000) return '${(tokens / 1000).toStringAsFixed(0)}K';
    return '$tokens';
  }
}
