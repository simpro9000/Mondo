import 'package:flutter/widgets.dart';
import 'package:lucide_icons/lucide_icons.dart';

/// Skill/connector models store icon identity as a plain string (so they
/// can come from a backend later without a code change). This resolves
/// that string to a concrete Lucide icon for rendering.
IconData resolveIcon(String name) {
  switch (name) {
    case 'layout-grid':
      return LucideIcons.layoutGrid;
    case 'pen-line':
      return LucideIcons.penLine;
    case 'code-2':
      return LucideIcons.code2;
    case 'search':
      return LucideIcons.search;
    case 'zap':
      return LucideIcons.zap;
    case 'graduation-cap':
      return LucideIcons.graduationCap;
    case 'bug':
      return LucideIcons.bug;
    case 'telescope':
      return LucideIcons.telescope;
    case 'shield-check':
      return LucideIcons.shieldCheck;
    case 'mail':
      return LucideIcons.mail;
    case 'clipboard-list':
      return LucideIcons.clipboardList;
    case 'list-checks':
      return LucideIcons.listChecks;
    case 'database':
      return LucideIcons.database;
    case 'megaphone':
      return LucideIcons.megaphone;
    case 'languages':
      return LucideIcons.languages;
    case 'hard-drive':
      return LucideIcons.hardDrive;
    case 'calendar':
      return LucideIcons.calendar;
    case 'file-text':
      return LucideIcons.fileText;
    case 'github':
      return LucideIcons.github;
    case 'slack':
      return LucideIcons.slack;
    case 'figma':
      return LucideIcons.figma;
    default:
      return LucideIcons.sparkles;
  }
}
