import 'dart:async';
import 'dart:math';
import '../models/enums.dart';
import '../models/message.dart';
import 'ai_service.dart';

/// Demo/offline implementation of [AiService]. Produces plausible,
/// mode-aware responses with a realistic streaming cadence so the full app
/// experience (typing indicator, token counter, citations, code blocks)
/// works end-to-end without a live commandrra 2.1 endpoint.
///
/// --- HOW TO CONNECT A REAL BACKEND ---
/// Create e.g. `lib/services/commandrra_api_service.dart` implementing
/// [AiService], point it at your endpoint (REST/SSE/WebSocket), and change
/// one line in `lib/providers/ai_service_provider.dart`:
///   final aiServiceProvider = Provider<AiService>((ref) => CommandrraApiService());
class MockAiService implements AiService {
  final Random _random = Random();

  @override
  Stream<String> sendMessage({
    required String prompt,
    required AssistantMode mode,
    required List<ChatMessage> history,
    List<Attachment> attachments = const [],
    String? activeSkillId,
  }) async* {
    final fullResponse = _buildResponse(prompt, mode, attachments, activeSkillId);
    final words = fullResponse.split(RegExp(r'(?<=\s)'));

    for (final word in words) {
      await Future.delayed(Duration(milliseconds: 12 + _random.nextInt(28)));
      yield word;
    }
  }

  @override
  Future<List<SourceRef>> fetchSources(String query) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return _mockSources(query);
  }

  @override
  int estimateTokens(String text) {
    // ~4 chars per token heuristic, matches common approximations.
    return (text.length / 4).ceil().clamp(1, 100000);
  }

  String _buildResponse(
    String prompt,
    AssistantMode mode,
    List<Attachment> attachments,
    String? skillId,
  ) {
    final attachmentNote = attachments.isNotEmpty
        ? '\n\n📎 لاحظت ${attachments.length} ${attachments.length == 1 ? "مرفق" : "مرفقات"} وأخذتها بعين الاعتبار في الإجابة.\n'
        : '';

    switch (mode) {
      case AssistantMode.chat:
        return _chatResponse(prompt) + attachmentNote;
      case AssistantMode.search:
        return _searchResponse(prompt);
      case AssistantMode.code:
        return _codeResponse(prompt) + attachmentNote;
    }
  }

  String _chatResponse(String prompt) {
    return '''فهمت سؤالك حول "${_truncate(prompt)}".

هذا رد تجريبي من **commandrra 2.1** في وضع الدردشة. عند ربط الـ API الحقيقي، هنا غادي يبان الجواب الفعلي مبني على النموذج ديالك.

بعض النقاط المهمة:
- الإجابة كتبان بشكل تدريجي (streaming) بحال ChatGPT
- كيدعم **Markdown** كامل، `code inline`، وقوائم
- كيحتفظ بسياق المحادثة السابقة

كيفاش نقدر نعاونك أكثر فهاد الموضوع؟''';
  }

  String _searchResponse(String prompt) {
    return '''بحثت في الويب حول "${_truncate(prompt)}" ولقيت هاد المعلومات:

بناءً على المصادر أدناه، هاد الموضوع كيتوفر عليه تغطية واسعة من عدة مصادر موثوقة. النتائج كتوضح اتفاق عام حول النقط الرئيسية، مع بعض الاختلافات البسيطة فالتفاصيل.

**النقاط الأساسية:**
1. المعلومة الأولى المستخرجة من المصادر
2. تفصيل إضافي مهم للسياق
3. آخر تحديث معروف حول الموضوع

شوف المصادر تحت للتفاصيل الكاملة والروابط الأصلية.''';
  }

  String _codeResponse(String prompt) {
    return '''هاد حل تجريبي لـ "${_truncate(prompt)}" فوضع البرمجة (بحال Opus):

```dart
// مثال: دالة توضح البنية المقترحة
class Solution {
  final String input;

  Solution(this.input);

  String process() {
    // منطق المعالجة كيتحط هنا
    return 'نتيجة معالجة: \$input';
  }
}

void main() {
  final solution = Solution('بيانات تجريبية');
  print(solution.process());
}
```

**شرح الكود:**
- بنية نظيفة وقابلة للتوسع
- تعليقات توضح كل خطوة
- جاهز للدمج مباشرة فمشروعك

بغيتي نفصّل شي جزء أو نبدل اللغة؟''';
  }

  List<SourceRef> _mockSources(String query) {
    final domains = [
      ('Wikipedia', 'ar.wikipedia.org'),
      ('Reuters', 'reuters.com'),
      ('TechCrunch', 'techcrunch.com'),
      ('GitHub Docs', 'docs.github.com'),
      ('Stack Overflow', 'stackoverflow.com'),
    ];
    final shuffled = List.of(domains)..shuffle(_random);
    return shuffled.take(3).map((d) {
      return SourceRef(
        title: '${_truncate(query, 40)} — ${d.$1}',
        url: 'https://${d.$2}/search?q=${Uri.encodeComponent(query)}',
        domain: d.$2,
        snippet: 'مقتطف تجريبي يوضح كيفاش غادي تبان النتيجة الحقيقية من ${d.$1} '
            'مع السياق المرتبط بسؤالك.',
      );
    }).toList();
  }

  String _truncate(String text, [int max = 60]) {
    return text.length > max ? '${text.substring(0, max)}...' : text;
  }
}
