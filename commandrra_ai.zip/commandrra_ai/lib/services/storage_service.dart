import 'package:shared_preferences/shared_preferences.dart';
import '../models/enums.dart';

/// Thin wrapper around SharedPreferences for simple key/value app state.
/// Conversation history uses Hive (see conversation_store.dart) since it's
/// structured data; this service is for small scalar settings.
class StorageService {
  static const _kOnboarded = 'onboarding_complete';
  static const _kPlanTier = 'plan_tier';
  static const _kTokensUsed = 'tokens_used';
  static const _kMessagesToday = 'messages_today';
  static const _kLastResetDay = 'last_reset_day';
  static const _kEnabledSkills = 'enabled_skills';
  static const _kConnectedServices = 'connected_services';

  final SharedPreferences _prefs;

  StorageService(this._prefs);

  static Future<StorageService> create() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService(prefs);
  }

  bool get hasOnboarded => _prefs.getBool(_kOnboarded) ?? false;
  Future<void> setOnboarded(bool value) => _prefs.setBool(_kOnboarded, value);

  PlanTier get planTier {
    final raw = _prefs.getString(_kPlanTier) ?? 'free';
    return PlanTier.values.firstWhere((t) => t.name == raw, orElse: () => PlanTier.free);
  }

  Future<void> setPlanTier(PlanTier tier) => _prefs.setString(_kPlanTier, tier.name);

  int get tokensUsed => _prefs.getInt(_kTokensUsed) ?? 0;
  Future<void> setTokensUsed(int value) => _prefs.setInt(_kTokensUsed, value);

  int get messagesToday => _prefs.getInt(_kMessagesToday) ?? 0;
  Future<void> setMessagesToday(int value) => _prefs.setInt(_kMessagesToday, value);

  int get lastResetDay => _prefs.getInt(_kLastResetDay) ?? 0;
  Future<void> setLastResetDay(int value) => _prefs.setInt(_kLastResetDay, value);

  List<String> get enabledSkillIds => _prefs.getStringList(_kEnabledSkills) ?? [];
  Future<void> setEnabledSkillIds(List<String> ids) => _prefs.setStringList(_kEnabledSkills, ids);

  List<String> get connectedServiceIds => _prefs.getStringList(_kConnectedServices) ?? [];
  Future<void> setConnectedServiceIds(List<String> ids) =>
      _prefs.setStringList(_kConnectedServices, ids);

  Future<void> clearAll() => _prefs.clear();
}
