import '../models/skill.dart';

/// Static catalog of built-in skills. In a production build this would be
/// fetched from the backend (so skills can ship without an app update);
/// kept local here for a fast, offline-capable demo.
class SkillsCatalog {
  SkillsCatalog._();

  static const List<SkillCategory> categories = [
    SkillCategory('الكل', 'layout-grid'),
    SkillCategory('كتابة', 'pen-line'),
    SkillCategory('برمجة', 'code-2'),
    SkillCategory('بحث', 'search'),
    SkillCategory('إنتاجية', 'zap'),
    SkillCategory('تعليم', 'graduation-cap'),
  ];

  static List<Skill> get all => [
        Skill(
          id: 'writer_pro',
          name: 'محرر النصوص المحترف',
          description: 'يراجع نصوصك ويحسّن الأسلوب والقواعد بلمسة احترافية',
          category: 'كتابة',
          icon: 'pen-line',
        ),
        Skill(
          id: 'code_reviewer',
          name: 'مراجع الكود',
          description: 'يفحص كودك ويقترح تحسينات في الأداء والبنية',
          category: 'برمجة',
          icon: 'code-2',
        ),
        Skill(
          id: 'debug_assistant',
          name: 'مساعد تصحيح الأخطاء',
          description: 'يحلل رسائل الخطأ ويقترح حلول خطوة بخطوة',
          category: 'برمجة',
          icon: 'bug',
        ),
        Skill(
          id: 'deep_research',
          name: 'البحث المعمق',
          description: 'يجمع معلومات من مصادر متعددة ويلخصها بشكل منظم',
          category: 'بحث',
          icon: 'telescope',
          isPro: true,
        ),
        Skill(
          id: 'fact_check',
          name: 'التحقق من الحقائق',
          description: 'يتحقق من صحة الادعاءات مقابل مصادر موثوقة',
          category: 'بحث',
          icon: 'shield-check',
        ),
        Skill(
          id: 'email_drafter',
          name: 'صياغة الإيميلات',
          description: 'يكتب إيميلات احترافية بالنبرة المناسبة للموقف',
          category: 'إنتاجية',
          icon: 'mail',
        ),
        Skill(
          id: 'meeting_summary',
          name: 'تلخيص الاجتماعات',
          description: 'يحول ملاحظات الاجتماع إلى ملخص ونقاط عمل واضحة',
          category: 'إنتاجية',
          icon: 'clipboard-list',
          isPro: true,
        ),
        Skill(
          id: 'concept_explainer',
          name: 'شرح المفاهيم',
          description: 'يبسّط المفاهيم المعقدة بأمثلة سهلة الفهم',
          category: 'تعليم',
          icon: 'graduation-cap',
        ),
        Skill(
          id: 'quiz_maker',
          name: 'صانع الاختبارات',
          description: 'يولّد أسئلة اختبار من أي محتوى تعليمي',
          category: 'تعليم',
          icon: 'list-checks',
        ),
        Skill(
          id: 'sql_builder',
          name: 'مولّد استعلامات SQL',
          description: 'يحول الوصف بالعربية إلى استعلامات SQL دقيقة',
          category: 'برمجة',
          icon: 'database',
          isPro: true,
        ),
        Skill(
          id: 'social_writer',
          name: 'كاتب منشورات التواصل',
          description: 'يصيغ منشورات جذابة لمنصات التواصل الاجتماعي',
          category: 'كتابة',
          icon: 'megaphone',
        ),
        Skill(
          id: 'translator_pro',
          name: 'مترجم احترافي',
          description: 'ترجمة دقيقة تحافظ على السياق والنبرة الأصلية',
          category: 'كتابة',
          icon: 'languages',
        ),
      ];
}
