import '../models/enums.dart';
import '../models/message.dart';

/// Contract every AI backend must satisfy. The rest of the app only ever
/// talks to this interface, so swapping [MockAiService] for a real
/// commandrra 2.1 HTTP/WebSocket client later is a one-line change in
/// providers/ai_service_provider.dart — nothing in the UI layer changes.
abstract class AiService {
  /// Streams response chunks for [prompt] in the given [mode]. Implementations
  /// should yield incremental text so the UI can render a typing effect.
  Stream<String> sendMessage({
    required String prompt,
    required AssistantMode mode,
    required List<ChatMessage> history,
    List<Attachment> attachments,
    String? activeSkillId,
  });

  /// Search-mode only: returns source citations for the last query.
  /// Mock implementations can return canned sources; a real backend would
  /// return this alongside (or ahead of) the streamed answer.
  Future<List<SourceRef>> fetchSources(String query);

  /// Rough token estimate for a piece of text — used to update the usage
  /// meter optimistically before the backend confirms actual usage.
  int estimateTokens(String text);
}
