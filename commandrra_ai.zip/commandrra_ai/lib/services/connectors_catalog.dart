import '../models/connector.dart';
import '../models/enums.dart';

/// Static catalog of available connectors. Connection state lives in
/// ConnectorsProvider; this file only defines what's offerable.
class ConnectorsCatalog {
  ConnectorsCatalog._();

  static List<Connector> get all => [
        Connector(
          id: 'gmail',
          name: 'Gmail',
          description: 'اقرأ وابحث في رسائل بريدك الإلكتروني',
          icon: 'mail',
          status: ConnectorStatus.disconnected,
        ),
        Connector(
          id: 'gdrive',
          name: 'Google Drive',
          description: 'الوصول لملفاتك ومستنداتك المخزنة',
          icon: 'hard-drive',
          status: ConnectorStatus.disconnected,
        ),
        Connector(
          id: 'gcal',
          name: 'Google Calendar',
          description: 'اطلع على مواعيدك وأنشئ أحداث جديدة',
          icon: 'calendar',
          status: ConnectorStatus.disconnected,
        ),
        Connector(
          id: 'notion',
          name: 'Notion',
          description: 'ابحث وحرر صفحات مساحة العمل ديالك',
          icon: 'file-text',
          status: ConnectorStatus.disconnected,
        ),
        Connector(
          id: 'github',
          name: 'GitHub',
          description: 'اطلع على المستودعات وافتح Pull Requests',
          icon: 'github',
          status: ConnectorStatus.disconnected,
        ),
        Connector(
          id: 'slack',
          name: 'Slack',
          description: 'ابحث في القنوات وأرسل رسائل',
          icon: 'slack',
          status: ConnectorStatus.comingSoon,
        ),
        Connector(
          id: 'figma',
          name: 'Figma',
          description: 'استعرض التصاميم واحصل على أوصاف مفصلة',
          icon: 'figma',
          status: ConnectorStatus.comingSoon,
        ),
      ];
}
