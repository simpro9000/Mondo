import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/enums.dart';
import '../models/plan.dart';
import 'storage_provider.dart';

class UsageNotifier extends StateNotifier<UsageState> {
  final Ref ref;

  UsageNotifier(this.ref) : super(_initial(ref)) {
    _maybeResetDaily();
  }

  static UsageState _initial(Ref ref) {
    final storage = ref.read(storageServiceProvider);
    return UsageState(
      tier: storage.planTier,
      tokensUsed: storage.tokensUsed,
      messagesSentToday: storage.messagesToday,
      cycleResetsAt: DateTime.now().add(const Duration(days: 30)),
    );
  }

  void _maybeResetDaily() {
    final storage = ref.read(storageServiceProvider);
    final today = DateTime.now();
    final todayKey = today.year * 10000 + today.month * 100 + today.day;
    if (storage.lastResetDay != todayKey) {
      storage.setLastResetDay(todayKey);
      storage.setMessagesToday(0);
      state = state.copyWith(messagesSentToday: 0);
    }
  }

  /// Returns false (and leaves state untouched) if the user is out of quota.
  bool recordUsage({required int tokens}) {
    if (state.isAtLimit) return false;
    if (state.hasDailyMessageLimit && state.dailyMessagesRemaining <= 0) return false;

    final storage = ref.read(storageServiceProvider);
    final newTokens = state.tokensUsed + tokens;
    final newMessages = state.messagesSentToday + 1;

    storage.setTokensUsed(newTokens);
    storage.setMessagesToday(newMessages);

    state = state.copyWith(tokensUsed: newTokens, messagesSentToday: newMessages);
    return true;
  }

  Future<void> changePlan(PlanTier tier) async {
    final storage = ref.read(storageServiceProvider);
    await storage.setPlanTier(tier);
    state = state.copyWith(tier: tier);
  }

  /// Dev/demo helper to simulate a monthly reset.
  Future<void> resetCycle() async {
    final storage = ref.read(storageServiceProvider);
    await storage.setTokensUsed(0);
    state = state.copyWith(
      tokensUsed: 0,
      cycleResetsAt: DateTime.now().add(const Duration(days: 30)),
    );
  }
}

final usageProvider = StateNotifierProvider<UsageNotifier, UsageState>((ref) {
  return UsageNotifier(ref);
});
