import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/enums.dart';
import '../models/message.dart';
import 'ai_service_provider.dart';
import 'conversations_provider.dart';
import 'usage_provider.dart';

/// The currently selected assistant mode (chat / search / code), driven by
/// the transforming command bar on the home & chat screens.
final activeModeProvider = StateProvider<AssistantMode>((ref) => AssistantMode.chat);

/// True while a response is actively streaming — drives the composer's
/// send/stop button and the typing indicator.
final isRespondingProvider = StateProvider<bool>((ref) => false);

/// Currently active skill id, if the user launched the composer from a
/// skill card. Cleared after each send.
final activeSkillIdProvider = StateProvider<String?>((ref) => null);

class ChatController {
  final Ref ref;
  ChatController(this.ref);

  Future<void> sendMessage({
    required String text,
    List<Attachment> attachments = const [],
  }) async {
    if (text.trim().isEmpty && attachments.isEmpty) return;

    final usage = ref.read(usageProvider);
    if (usage.isAtLimit) {
      throw const TokenLimitException();
    }
    if (usage.hasDailyMessageLimit && usage.dailyMessagesRemaining <= 0) {
      throw const DailyLimitException();
    }

    final mode = ref.read(activeModeProvider);
    final skillId = ref.read(activeSkillIdProvider);
    final conversations = ref.read(conversationsProvider.notifier);
    final aiService = ref.read(aiServiceProvider);

    // Ensure there's an active conversation.
    var activeId = ref.read(activeConversationIdProvider);
    if (activeId == null) {
      final convo = conversations.createConversation(mode: mode);
      activeId = convo.id;
      ref.read(activeConversationIdProvider.notifier).state = activeId;
    }

    final userMessage = ChatMessage(
      role: MessageRole.user,
      content: text,
      mode: mode,
      attachments: attachments,
      status: MessageStatus.complete,
    );
    conversations.addMessage(activeId, userMessage);

    final assistantMessage = ChatMessage(
      role: MessageRole.assistant,
      content: '',
      mode: mode,
      status: MessageStatus.streaming,
      skillUsed: skillId,
    );
    conversations.addMessage(activeId, assistantMessage);

    ref.read(isRespondingProvider.notifier).state = true;
    ref.read(activeSkillIdProvider.notifier).state = null;

    final history = ref.read(activeConversationProvider)?.messages ?? [];

    try {
      final buffer = StringBuffer();
      await for (final chunk in aiService.sendMessage(
        prompt: text,
        mode: mode,
        history: history,
        attachments: attachments,
        activeSkillId: skillId,
      )) {
        buffer.write(chunk);
        conversations.updateLastMessageContent(activeId, buffer.toString());
      }

      if (mode == AssistantMode.search) {
        final sources = await aiService.fetchSources(text);
        final convo = ref.read(activeConversationProvider);
        if (convo != null && convo.messages.isNotEmpty) {
          convo.messages.last.sources.addAll(sources);
        }
      }

      conversations.updateLastMessageContent(
        activeId,
        buffer.toString(),
        status: MessageStatus.complete,
      );

      final tokensUsed = aiService.estimateTokens(text) + aiService.estimateTokens(buffer.toString());
      ref.read(usageProvider.notifier).recordUsage(tokens: tokensUsed);
    } catch (e) {
      conversations.updateLastMessageContent(
        activeId,
        'عذرًا، وقع خطأ أثناء معالجة الطلب. حاول مرة أخرى.',
        status: MessageStatus.error,
      );
    } finally {
      ref.read(isRespondingProvider.notifier).state = false;
    }
  }

  void startNewConversation() {
    ref.read(activeConversationIdProvider.notifier).state = null;
    ref.read(activeModeProvider.notifier).state = AssistantMode.chat;
  }
}

final chatControllerProvider = Provider((ref) => ChatController(ref));

class TokenLimitException implements Exception {
  const TokenLimitException();
}

class DailyLimitException implements Exception {
  const DailyLimitException();
}
