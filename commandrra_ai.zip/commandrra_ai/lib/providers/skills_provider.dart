import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/skill.dart';
import '../services/skills_catalog.dart';
import 'storage_provider.dart';

class SkillsNotifier extends StateNotifier<List<Skill>> {
  final Ref ref;

  SkillsNotifier(this.ref) : super(SkillsCatalog.all) {
    _restoreEnabled();
  }

  void _restoreEnabled() {
    final storage = ref.read(storageServiceProvider);
    final enabledIds = storage.enabledSkillIds.toSet();
    state = [
      for (final skill in state) skill..enabled = enabledIds.contains(skill.id),
    ];
  }

  void toggle(String skillId) {
    state = [
      for (final skill in state)
        if (skill.id == skillId) (skill..enabled = !skill.enabled) else skill,
    ];
    final storage = ref.read(storageServiceProvider);
    storage.setEnabledSkillIds(
      state.where((s) => s.enabled).map((s) => s.id).toList(),
    );
  }

  List<Skill> get enabledSkills => state.where((s) => s.enabled).toList();
}

final skillsProvider = StateNotifierProvider<SkillsNotifier, List<Skill>>((ref) {
  return SkillsNotifier(ref);
});

final skillCategoryFilterProvider = StateProvider<String>((ref) => 'الكل');

final filteredSkillsProvider = Provider<List<Skill>>((ref) {
  final skills = ref.watch(skillsProvider);
  final category = ref.watch(skillCategoryFilterProvider);
  if (category == 'الكل') return skills;
  return skills.where((s) => s.category == category).toList();
});
