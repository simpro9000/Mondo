import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/connector.dart';
import '../models/enums.dart';
import '../services/connectors_catalog.dart';
import 'storage_provider.dart';

class ConnectorsNotifier extends StateNotifier<List<Connector>> {
  final Ref ref;

  ConnectorsNotifier(this.ref) : super(ConnectorsCatalog.all) {
    _restoreConnected();
  }

  void _restoreConnected() {
    final storage = ref.read(storageServiceProvider);
    final connectedIds = storage.connectedServiceIds.toSet();
    state = [
      for (final c in state)
        if (connectedIds.contains(c.id))
          (c
            ..status = ConnectorStatus.connected
            ..connectedAt = DateTime.now())
        else
          c,
    ];
  }

  /// Simulates an OAuth round-trip. A real integration would launch a
  /// webview/browser flow and await the callback here instead.
  Future<void> connect(String id) async {
    await Future.delayed(const Duration(milliseconds: 900));
    state = [
      for (final c in state)
        if (c.id == id)
          (c
            ..status = ConnectorStatus.connected
            ..connectedAt = DateTime.now())
        else
          c,
    ];
    _persist();
  }

  void disconnect(String id) {
    state = [
      for (final c in state)
        if (c.id == id) (c..status = ConnectorStatus.disconnected) else c,
    ];
    _persist();
  }

  void _persist() {
    final storage = ref.read(storageServiceProvider);
    storage.setConnectedServiceIds(
      state.where((c) => c.status == ConnectorStatus.connected).map((c) => c.id).toList(),
    );
  }
}

final connectorsProvider = StateNotifierProvider<ConnectorsNotifier, List<Connector>>((ref) {
  return ConnectorsNotifier(ref);
});
