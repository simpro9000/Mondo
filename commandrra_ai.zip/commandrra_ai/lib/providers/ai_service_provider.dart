import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/ai_service.dart';
import '../services/mock_ai_service.dart';

/// The ONE line to change when wiring a real commandrra 2.1 backend:
///
///   final aiServiceProvider = Provider<AiService>((ref) {
///     return CommandrraApiService(baseUrl: 'https://api.commandrra.ai/v1');
///   });
///
/// Everything downstream (chatProvider, search, code mode) depends on the
/// AiService interface, not on MockAiService directly, so no other file
/// needs to change.
final aiServiceProvider = Provider<AiService>((ref) => MockAiService());
