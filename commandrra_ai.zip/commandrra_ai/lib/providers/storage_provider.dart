import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/storage_service.dart';

/// Overridden in main.dart with a fully-initialized StorageService once
/// SharedPreferences has loaded, so it's always synchronously available to
/// every other provider from the first frame.
final storageServiceProvider = Provider<StorageService>((ref) {
  throw UnimplementedError('storageServiceProvider must be overridden in main.dart');
});
