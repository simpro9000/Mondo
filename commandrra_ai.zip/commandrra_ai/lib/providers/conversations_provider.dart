import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/conversation.dart';
import '../models/enums.dart';
import '../models/message.dart';

class ConversationsNotifier extends StateNotifier<List<Conversation>> {
  ConversationsNotifier() : super([]);

  Conversation createConversation({AssistantMode mode = AssistantMode.chat}) {
    final convo = Conversation(lastMode: mode);
    state = [convo, ...state];
    return convo;
  }

  void addMessage(String conversationId, ChatMessage message) {
    state = [
      for (final c in state)
        if (c.id == conversationId)
          (c
            ..messages.add(message)
            ..updatedAt = DateTime.now())
        else
          c,
    ];
    _retitleIfNeeded(conversationId);
  }

  void updateLastMessageContent(String conversationId, String content, {MessageStatus? status}) {
    final convo = state.firstWhere((c) => c.id == conversationId, orElse: () => state.first);
    if (convo.messages.isEmpty) return;
    final last = convo.messages.last;
    last.content = content;
    if (status != null) last.status = status;
    state = [...state]; // trigger rebuild
  }

  void _retitleIfNeeded(String conversationId) {
    final convo = state.firstWhere((c) => c.id == conversationId);
    if (convo.title == 'محادثة جديدة' && convo.messages.isNotEmpty) {
      final firstUserMsg = convo.messages.firstWhere(
        (m) => m.isUser,
        orElse: () => convo.messages.first,
      );
      convo.title = firstUserMsg.content.length > 40
          ? '${firstUserMsg.content.substring(0, 40)}...'
          : firstUserMsg.content;
      state = [...state];
    }
  }

  void deleteConversation(String id) {
    state = state.where((c) => c.id != id).toList();
  }

  void togglePin(String id) {
    state = [
      for (final c in state)
        if (c.id == id) (c..pinned = !c.pinned) else c,
    ];
  }

  void renameConversation(String id, String newTitle) {
    state = [
      for (final c in state)
        if (c.id == id) (c..title = newTitle) else c,
    ];
  }
}

final conversationsProvider =
    StateNotifierProvider<ConversationsNotifier, List<Conversation>>((ref) {
  return ConversationsNotifier();
});

/// Currently open conversation id — null means the "new chat" empty state.
final activeConversationIdProvider = StateProvider<String?>((ref) => null);

final activeConversationProvider = Provider<Conversation?>((ref) {
  final id = ref.watch(activeConversationIdProvider);
  final conversations = ref.watch(conversationsProvider);
  if (id == null) return null;
  try {
    return conversations.firstWhere((c) => c.id == id);
  } catch (_) {
    return null;
  }
});
