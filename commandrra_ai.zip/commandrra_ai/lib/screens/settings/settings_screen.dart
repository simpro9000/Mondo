import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../providers/conversations_provider.dart';
import '../../providers/storage_provider.dart';
import '../../providers/usage_provider.dart';
import '../../widgets/common/usage_meter.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usage = ref.watch(usageProvider);

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: Text('الإعدادات', style: AppTypography.headingSm),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.bgElevated,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.borderSubtle),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppColors.amber,
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(LucideIcons.terminal, color: AppColors.bgPrimary, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppConstants.modelName, style: AppTypography.headingSm),
                      const SizedBox(height: 2),
                      Text(
                        'خطة ${usage.plan.tier.label}',
                        style: AppTypography.caption.copyWith(color: AppColors.amber),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () => context.push('/plans'),
                  child: const Text('إدارة'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const UsageMeterBar(),
          const SizedBox(height: 24),
          _SectionTitle('عام'),
          _SettingsTile(
            icon: LucideIcons.sparkles,
            label: 'المهارات',
            onTap: () => context.push('/skills'),
          ),
          _SettingsTile(
            icon: LucideIcons.plug,
            label: 'الموصلات',
            onTap: () => context.push('/connectors'),
          ),
          _SettingsTile(
            icon: LucideIcons.creditCard,
            label: 'الخطط والفوترة',
            onTap: () => context.push('/plans'),
          ),
          const SizedBox(height: 20),
          _SectionTitle('البيانات'),
          _SettingsTile(
            icon: LucideIcons.trash2,
            label: 'حذف كل المحادثات',
            danger: true,
            onTap: () => _confirmClearHistory(context, ref),
          ),
          const SizedBox(height: 20),
          _SectionTitle('حول التطبيق'),
          _SettingsTile(icon: LucideIcons.info, label: 'الإصدار 1.0.0', onTap: null),
          _SettingsTile(
            icon: LucideIcons.fileText,
            label: 'شروط الاستخدام',
            onTap: () {},
          ),
          _SettingsTile(
            icon: LucideIcons.shield,
            label: 'سياسة الخصوصية',
            onTap: () {},
          ),
        ],
      ),
    );
  }

  void _confirmClearHistory(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('حذف كل المحادثات؟', style: AppTypography.headingMd),
        content: Text(
          'هاد الإجراء ما يمكنش نرجعو فيه. غادي تتحذف جميع محادثاتك نهائيًا.',
          style: AppTypography.bodyMd.copyWith(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          TextButton(
            onPressed: () {
              final conversations = ref.read(conversationsProvider);
              for (final c in List.of(conversations)) {
                ref.read(conversationsProvider.notifier).deleteConversation(c.id);
              }
              ref.read(activeConversationIdProvider.notifier).state = null;
              Navigator.pop(context);
            },
            child: Text('حذف', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, right: 4),
      child: Text(title, style: AppTypography.overline),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool danger;

  const _SettingsTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = danger ? AppColors.danger : AppColors.textPrimary;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: ListTile(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: Icon(icon, size: 19, color: danger ? AppColors.danger : AppColors.textSecondary),
        title: Text(label, style: AppTypography.bodyMd.copyWith(color: color)),
        trailing: onTap != null
            ? const Icon(LucideIcons.chevronLeft, size: 17, color: AppColors.textTertiary)
            : null,
        onTap: onTap,
      ),
    );
  }
}
