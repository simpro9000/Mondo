import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/skill.dart';
import '../../providers/skills_provider.dart';
import '../../providers/usage_provider.dart';
import '../../services/skills_catalog.dart';
import '../../widgets/common/icon_resolver.dart';

class SkillsScreen extends ConsumerWidget {
  const SkillsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final skills = ref.watch(filteredSkillsProvider);
    final selectedCategory = ref.watch(skillCategoryFilterProvider);
    final enabledCount = ref.watch(skillsProvider).where((s) => s.enabled).length;

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: Text('المهارات', style: AppTypography.headingSm),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Row(
              children: [
                Icon(LucideIcons.sparkles, size: 15, color: AppColors.textTertiary),
                const SizedBox(width: 8),
                Text(
                  '$enabledCount مهارة مفعّلة',
                  style: AppTypography.caption,
                ),
              ],
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: SkillsCatalog.categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final category = SkillsCatalog.categories[i];
                final isSelected = category.name == selectedCategory;
                return ChoiceChip(
                  label: Text(category.name),
                  selected: isSelected,
                  selectedColor: AppColors.amberDim,
                  labelStyle: AppTypography.bodySm.copyWith(
                    color: isSelected ? AppColors.amber : AppColors.textSecondary,
                  ),
                  onSelected: (_) =>
                      ref.read(skillCategoryFilterProvider.notifier).state = category.name,
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: skills.length,
              itemBuilder: (context, i) => _SkillCard(skill: skills[i]),
            ),
          ),
        ],
      ),
    );
  }
}

class _SkillCard extends ConsumerWidget {
  final Skill skill;

  const _SkillCard({required this.skill});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usage = ref.watch(usageProvider);
    final isLocked = skill.isPro && usage.tier == PlanTier.free;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: skill.enabled ? AppColors.amberDim : AppColors.borderSubtle,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.bgOverlay,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(resolveIcon(skill.icon), size: 20, color: AppColors.amber),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        skill.name,
                        style: AppTypography.headingSm,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (skill.isPro) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.amberDim,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          'PRO',
                          style: AppTypography.caption.copyWith(fontSize: 9, color: AppColors.amber),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  skill.description,
                  style: AppTypography.bodySm.copyWith(color: AppColors.textSecondary),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: skill.enabled,
            activeThumbColor: AppColors.amber,
            onChanged: isLocked
                ? null
                : (_) => ref.read(skillsProvider.notifier).toggle(skill.id),
          ),
        ],
      ),
    );
  }
}
