import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../providers/chat_controller.dart';
import '../../providers/conversations_provider.dart';
import '../../widgets/chat/composer.dart';
import '../../widgets/chat/empty_state.dart';
import '../../widgets/chat/history_drawer.dart';
import '../../widgets/chat/message_bubble.dart';
import '../../widgets/common/mode_selector.dart';
import '../../widgets/common/usage_meter.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});

  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  final _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent + 120,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final conversation = ref.watch(activeConversationProvider);

    ref.listen(activeConversationProvider, (prev, next) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    });

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      drawer: const HistoryDrawer(),
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            onPressed: () => Scaffold.of(context).openDrawer(),
            icon: const Icon(LucideIcons.panelLeft, size: 21),
          ),
        ),
        title: Text(AppConstants.appName, style: AppTypography.headingSm),
        actions: [
          const Padding(
            padding: EdgeInsets.only(left: 8),
            child: UsageMeterPill(),
          ),
          IconButton(
            onPressed: () => ref.read(chatControllerProvider).startNewConversation(),
            icon: const Icon(LucideIcons.squarePen, size: 20),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: const ModeSelector(),
            ),
            Expanded(
              child: conversation == null || conversation.isEmpty
                  ? const ChatEmptyState()
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                      itemCount: conversation.messages.length,
                      itemBuilder: (context, i) {
                        return MessageBubble(message: conversation.messages[i]);
                      },
                    ),
            ),
            const Composer(),
          ],
        ),
      ),
    );
  }
}
