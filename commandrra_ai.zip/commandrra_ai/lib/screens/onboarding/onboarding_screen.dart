import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../providers/storage_provider.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _pageController = PageController();
  int _page = 0;

  static final _pages = [
    _OnboardPage(
      icon: LucideIcons.terminal,
      gradient: AppColors.chatGradient,
      title: AppConstants.modelName,
      subtitle: 'مساعد ذكاء اصطناعي واحد، ثلاث قدرات: دردشة، بحث، وبرمجة.',
    ),
    _OnboardPage(
      icon: LucideIcons.messageCircle,
      gradient: AppColors.chatGradient,
      title: 'دردشة طبيعية',
      subtitle: 'اسأل أي سؤال واحصل على إجابات واضحة ومفصّلة، بحال تهدر مع خبير.',
    ),
    _OnboardPage(
      icon: LucideIcons.search,
      gradient: AppColors.searchGradient,
      title: 'بحث بمصادر موثوقة',
      subtitle: 'كل جواب فوضع البحث كيجي مع مصادره — تقدر تتحقق منها بنفسك.',
    ),
    _OnboardPage(
      icon: LucideIcons.code2,
      gradient: AppColors.codeGradient,
      title: 'برمجة على مستوى عالٍ',
      subtitle: 'اكتب، صحّح، وافهم الكود بمساعدة تشتغل بحال مهندس محترف.',
    ),
    _OnboardPage(
      icon: LucideIcons.sparkles,
      gradient: const [Color(0xFF8B5CF6), AppColors.amber],
      title: 'مهارات وموصلات',
      subtitle: 'فعّل مهارات جاهزة واربط خدماتك (بريد، تقويم، ملفات) باش توسّع القدرات.',
    ),
  ];

  Future<void> _finish() async {
    final storage = ref.read(storageServiceProvider);
    await storage.setOnboarded(true);
    if (mounted) context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _page == _pages.length - 1;

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: TextButton(
                  onPressed: _finish,
                  child: Text('تخطي', style: AppTypography.bodySm.copyWith(color: AppColors.textTertiary)),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (context, i) => _pages[i],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(_pages.length, (i) {
                  final active = i == _page;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: active ? 20 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: active ? AppColors.amber : AppColors.border,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  );
                }),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLast
                      ? _finish
                      : () => _pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeOut,
                          ),
                  child: Text(isLast ? 'ابدأ الآن' : 'التالي'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardPage extends StatelessWidget {
  final IconData icon;
  final List<Color> gradient;
  final String title;
  final String subtitle;

  const _OnboardPage({
    required this.icon,
    required this.gradient,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: gradient),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(color: gradient.first.withValues(alpha: 0.3), blurRadius: 32, offset: const Offset(0, 12)),
              ],
            ),
            child: Icon(icon, size: 44, color: AppColors.bgPrimary),
          ),
          const SizedBox(height: 32),
          Text(title, style: AppTypography.displayMd, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          Text(
            subtitle,
            style: AppTypography.bodyMd.copyWith(color: AppColors.textSecondary),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
