import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/plan.dart';
import '../../providers/usage_provider.dart';
import '../../widgets/common/usage_meter.dart';

class PlansScreen extends ConsumerWidget {
  const PlansScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentTier = ref.watch(usageProvider).tier;

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: Text('الخطط والاشتراك', style: AppTypography.headingSm),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const UsageMeterBar(),
          const SizedBox(height: 20),
          _PlanCard(
            plan: PlanInfo.free,
            isCurrent: currentTier == PlanTier.free,
            accent: AppColors.planFree,
          ),
          _PlanCard(
            plan: PlanInfo.pro,
            isCurrent: currentTier == PlanTier.pro,
            accent: AppColors.planPro,
            featured: true,
          ),
          _PlanCard(
            plan: PlanInfo.team,
            isCurrent: currentTier == PlanTier.team,
            accent: AppColors.planTeam,
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              'الأسعار تجريبية للعرض فقط — الفوترة الحقيقية تحتاج ربط مزود دفع.',
              textAlign: TextAlign.center,
              style: AppTypography.caption,
            ),
          ),
        ],
      ),
    );
  }
}

class _PlanCard extends ConsumerWidget {
  final PlanInfo plan;
  final bool isCurrent;
  final Color accent;
  final bool featured;

  const _PlanCard({
    required this.plan,
    required this.isCurrent,
    required this.accent,
    this.featured = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: featured ? AppColors.amber : AppColors.borderSubtle,
          width: featured ? 1.4 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
              ),
              const SizedBox(width: 8),
              Text(plan.tier.label, style: AppTypography.headingMd),
              if (featured) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.amberDim,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'الأكثر شعبية',
                    style: AppTypography.caption.copyWith(fontSize: 10, color: AppColors.amber),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                plan.priceMonthly == 0 ? 'مجاني' : '\$${plan.priceMonthly.toStringAsFixed(2)}',
                style: AppTypography.displayMd,
              ),
              if (plan.priceMonthly > 0)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4, right: 4),
                  child: Text('/ شهريًا', style: AppTypography.caption),
                ),
            ],
          ),
          const SizedBox(height: 14),
          ...plan.features.map((f) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Icon(
                      f.included ? LucideIcons.check : LucideIcons.x,
                      size: 15,
                      color: f.included ? AppColors.success : AppColors.textDisabled,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        f.label,
                        style: AppTypography.bodySm.copyWith(
                          color: f.included ? AppColors.textPrimary : AppColors.textDisabled,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: isCurrent
                ? OutlinedButton(
                    onPressed: null,
                    child: const Text('خطتك الحالية'),
                  )
                : ElevatedButton(
                    onPressed: () => ref.read(usageProvider.notifier).changePlan(plan.tier),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: featured ? AppColors.amber : AppColors.bgOverlay,
                      foregroundColor: featured ? AppColors.bgPrimary : AppColors.textPrimary,
                    ),
                    child: Text(plan.tier == PlanTier.free ? 'التبديل للمجاني' : 'الترقية الآن'),
                  ),
          ),
        ],
      ),
    );
  }
}
