import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/connector.dart';
import '../../models/enums.dart';
import '../../providers/connectors_provider.dart';
import '../../widgets/common/icon_resolver.dart';

class ConnectorsScreen extends ConsumerWidget {
  const ConnectorsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final connectors = ref.watch(connectorsProvider);
    final connectedCount = connectors.where((c) => c.status == ConnectorStatus.connected).length;

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: Text('الموصلات', style: AppTypography.headingSm),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'اربط commandrra بخدماتك باش يقدر يجيب سياق مباشرة من بريدك، تقويمك، وملفاتك.',
            style: AppTypography.bodySm.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 6),
          Text('$connectedCount من ${connectors.length} متصلة', style: AppTypography.caption),
          const SizedBox(height: 16),
          ...connectors.map((c) => _ConnectorCard(connector: c)),
        ],
      ),
    );
  }
}

class _ConnectorCard extends ConsumerStatefulWidget {
  final Connector connector;

  const _ConnectorCard({required this.connector});

  @override
  ConsumerState<_ConnectorCard> createState() => _ConnectorCardState();
}

class _ConnectorCardState extends ConsumerState<_ConnectorCard> {
  bool _connecting = false;

  Future<void> _handleConnect() async {
    setState(() => _connecting = true);
    await ref.read(connectorsProvider.notifier).connect(widget.connector.id);
    if (mounted) setState(() => _connecting = false);
  }

  @override
  Widget build(BuildContext context) {
    final connector = widget.connector;
    final isConnected = connector.status == ConnectorStatus.connected;
    final isComingSoon = connector.status == ConnectorStatus.comingSoon;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.bgOverlay,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(resolveIcon(connector.icon), size: 20, color: AppColors.cyan),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(connector.name, style: AppTypography.headingSm),
                const SizedBox(height: 3),
                Text(
                  connector.description,
                  style: AppTypography.bodySm.copyWith(color: AppColors.textSecondary),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _ActionButton(
            isConnected: isConnected,
            isComingSoon: isComingSoon,
            isLoading: _connecting,
            onConnect: _handleConnect,
            onDisconnect: () => ref.read(connectorsProvider.notifier).disconnect(connector.id),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final bool isConnected;
  final bool isComingSoon;
  final bool isLoading;
  final VoidCallback onConnect;
  final VoidCallback onDisconnect;

  const _ActionButton({
    required this.isConnected,
    required this.isComingSoon,
    required this.isLoading,
    required this.onConnect,
    required this.onDisconnect,
  });

  @override
  Widget build(BuildContext context) {
    if (isComingSoon) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.bgOverlay,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text('قريبًا', style: AppTypography.caption),
      );
    }

    if (isLoading) {
      return const SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.amber),
      );
    }

    if (isConnected) {
      return OutlinedButton.icon(
        onPressed: onDisconnect,
        icon: const Icon(LucideIcons.check, size: 14, color: AppColors.success),
        label: const Text('متصل'),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: AppColors.success),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          textStyle: AppTypography.caption.copyWith(color: AppColors.success),
        ),
      );
    }

    return ElevatedButton(
      onPressed: onConnect,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        textStyle: AppTypography.caption,
      ),
      child: const Text('ربط'),
    );
  }
}
