import 'enums.dart';

/// A connector links commandrra to an external service so it can pull
/// context (calendar, docs, email...) into a conversation. This is a UI /
/// state model only — wiring a real OAuth flow happens in ConnectorService.
class Connector {
  final String id;
  final String name;
  final String description;
  final String icon;
  ConnectorStatus status;
  DateTime? connectedAt;

  Connector({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    this.status = ConnectorStatus.disconnected,
    this.connectedAt,
  });
}
