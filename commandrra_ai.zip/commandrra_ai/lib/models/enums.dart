/// The active mode of the assistant. Drives the command bar's shape, the
/// accent gradient, and which system prompt / tool-set is used server-side.
enum AssistantMode {
  chat,
  search,
  code;

  String get label => switch (this) {
        AssistantMode.chat => 'دردشة',
        AssistantMode.search => 'بحث',
        AssistantMode.code => 'برمجة',
      };

  String get hint => switch (this) {
        AssistantMode.chat => 'اسأل commandrra أي شيء...',
        AssistantMode.search => 'ابحث في الويب بمصادر موثوقة...',
        AssistantMode.code => 'صف الكود أو الميزة التي تريدها...',
      };
}

enum MessageRole { user, assistant, system }

enum MessageStatus { sending, streaming, complete, error }

/// Attachment kinds a message can carry.
enum AttachmentType { image, file, code }

enum PlanTier {
  free,
  pro,
  team;

  String get label => switch (this) {
        PlanTier.free => 'مجاني',
        PlanTier.pro => 'برو',
        PlanTier.team => 'فريق',
      };
}

enum ConnectorStatus { connected, disconnected, comingSoon }

/// A citation/source surfaced during search mode.
class SourceKind {
  static const web = 'web';
  static const doc = 'doc';
}
