import 'package:uuid/uuid.dart';
import 'enums.dart';
import 'message.dart';

const _uuid = Uuid();

class Conversation {
  final String id;
  String title;
  final List<ChatMessage> messages;
  AssistantMode lastMode;
  final DateTime createdAt;
  DateTime updatedAt;
  bool pinned;

  Conversation({
    String? id,
    this.title = 'محادثة جديدة',
    List<ChatMessage>? messages,
    this.lastMode = AssistantMode.chat,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.pinned = false,
  })  : id = id ?? _uuid.v4(),
        messages = messages ?? [],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  bool get isEmpty => messages.isEmpty;

  String get preview {
    if (messages.isEmpty) return 'ابدأ محادثة جديدة';
    final lastUserMsg = messages.lastWhere(
      (m) => m.isUser,
      orElse: () => messages.last,
    );
    return lastUserMsg.content.length > 60
        ? '${lastUserMsg.content.substring(0, 60)}...'
        : lastUserMsg.content;
  }
}
