import 'package:uuid/uuid.dart';
import 'enums.dart';

const _uuid = Uuid();

class Attachment {
  final String id;
  final AttachmentType type;
  final String name;
  final String? localPath;
  final String? mimeType;
  final int? sizeBytes;

  Attachment({
    String? id,
    required this.type,
    required this.name,
    this.localPath,
    this.mimeType,
    this.sizeBytes,
  }) : id = id ?? _uuid.v4();

  String get sizeLabel {
    if (sizeBytes == null) return '';
    final kb = sizeBytes! / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(0)} KB';
    return '${(kb / 1024).toStringAsFixed(1)} MB';
  }
}

/// A source citation shown under a search-mode response.
class SourceRef {
  final String title;
  final String url;
  final String domain;
  final String snippet;

  const SourceRef({
    required this.title,
    required this.url,
    required this.domain,
    required this.snippet,
  });
}

/// A single chat message — user or assistant — including optional
/// attachments, streamed content, citations (search mode), and code blocks
/// (code mode).
class ChatMessage {
  final String id;
  final MessageRole role;
  String content;
  MessageStatus status;
  final DateTime createdAt;
  final AssistantMode mode;
  final List<Attachment> attachments;
  final List<SourceRef> sources;
  final int? tokensUsed;
  final String? skillUsed;

  ChatMessage({
    String? id,
    required this.role,
    this.content = '',
    this.status = MessageStatus.complete,
    DateTime? createdAt,
    this.mode = AssistantMode.chat,
    List<Attachment>? attachments,
    List<SourceRef>? sources,
    this.tokensUsed,
    this.skillUsed,
  })  : id = id ?? _uuid.v4(),
        createdAt = createdAt ?? DateTime.now(),
        attachments = attachments ?? [],
        sources = sources ?? [];

  bool get isUser => role == MessageRole.user;
  bool get isStreaming => status == MessageStatus.streaming;
}
