import 'enums.dart';
import '../core/constants/app_constants.dart';

class PlanFeature {
  final String label;
  final bool included;

  const PlanFeature(this.label, {this.included = true});
}

class PlanInfo {
  final PlanTier tier;
  final int monthlyTokens;
  final int dailyMessages; // -1 = unlimited
  final double priceMonthly;
  final List<PlanFeature> features;

  const PlanInfo({
    required this.tier,
    required this.monthlyTokens,
    required this.dailyMessages,
    required this.priceMonthly,
    required this.features,
  });

  static const free = PlanInfo(
    tier: PlanTier.free,
    monthlyTokens: PlanLimits.freeMonthlyTokens,
    dailyMessages: PlanLimits.freeDailyMessages,
    priceMonthly: 0,
    features: [
      PlanFeature('50 ألف توكن شهريًا'),
      PlanFeature('20 رسالة يوميًا'),
      PlanFeature('دردشة + بحث أساسي'),
      PlanFeature('3 مهارات نشطة'),
      PlanFeature('برمجة متقدمة', included: false),
      PlanFeature('موصلات خارجية', included: false),
    ],
  );

  static const pro = PlanInfo(
    tier: PlanTier.pro,
    monthlyTokens: PlanLimits.proMonthlyTokens,
    dailyMessages: PlanLimits.proDailyMessages,
    priceMonthly: PlanLimits.proPriceMonthly,
    features: [
      PlanFeature('مليون توكن شهريًا'),
      PlanFeature('رسائل غير محدودة'),
      PlanFeature('دردشة + بحث + برمجة كاملة'),
      PlanFeature('مهارات غير محدودة'),
      PlanFeature('تحليل الصور والملفات'),
      PlanFeature('5 موصلات خارجية'),
    ],
  );

  static const team = PlanInfo(
    tier: PlanTier.team,
    monthlyTokens: PlanLimits.teamMonthlyTokens,
    dailyMessages: PlanLimits.teamDailyMessages,
    priceMonthly: PlanLimits.teamPriceMonthly,
    features: [
      PlanFeature('5 ملايين توكن شهريًا (مشترك)'),
      PlanFeature('كل ميزات برو'),
      PlanFeature('موصلات غير محدودة'),
      PlanFeature('مساحة عمل مشتركة'),
      PlanFeature('أولوية في زمن الاستجابة'),
      PlanFeature('دعم مخصص'),
    ],
  );

  static PlanInfo forTier(PlanTier tier) => switch (tier) {
        PlanTier.free => free,
        PlanTier.pro => pro,
        PlanTier.team => team,
      };
}

/// Live usage tracking for the current billing cycle.
class UsageState {
  final PlanTier tier;
  final int tokensUsed;
  final int messagesSentToday;
  final DateTime cycleResetsAt;

  const UsageState({
    required this.tier,
    required this.tokensUsed,
    required this.messagesSentToday,
    required this.cycleResetsAt,
  });

  PlanInfo get plan => PlanInfo.forTier(tier);

  double get tokenUsageRatio =>
      plan.monthlyTokens == 0 ? 0 : (tokensUsed / plan.monthlyTokens).clamp(0, 1);

  int get tokensRemaining => (plan.monthlyTokens - tokensUsed).clamp(0, plan.monthlyTokens);

  bool get isNearLimit => tokenUsageRatio >= 0.85;
  bool get isAtLimit => tokenUsageRatio >= 1.0;

  bool get hasDailyMessageLimit => plan.dailyMessages != -1;
  int get dailyMessagesRemaining =>
      hasDailyMessageLimit ? (plan.dailyMessages - messagesSentToday).clamp(0, plan.dailyMessages) : -1;

  UsageState copyWith({
    PlanTier? tier,
    int? tokensUsed,
    int? messagesSentToday,
    DateTime? cycleResetsAt,
  }) {
    return UsageState(
      tier: tier ?? this.tier,
      tokensUsed: tokensUsed ?? this.tokensUsed,
      messagesSentToday: messagesSentToday ?? this.messagesSentToday,
      cycleResetsAt: cycleResetsAt ?? this.cycleResetsAt,
    );
  }
}
