/// A "Skill" is a packaged capability — a focused prompt + behavior preset
/// the assistant can run (e.g. "Resume Reviewer", "SQL Explainer"). Users
/// browse a catalog and enable the ones relevant to them; enabled skills
/// surface as quick-launch chips above the composer.
class Skill {
  final String id;
  final String name;
  final String description;
  final String category;
  final String icon; // lucide icon name, resolved in the UI layer
  final bool isPro;
  bool enabled;
  final int usageCount;

  Skill({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.icon,
    this.isPro = false,
    this.enabled = false,
    this.usageCount = 0,
  });
}

class SkillCategory {
  final String name;
  final String icon;

  const SkillCategory(this.name, this.icon);
}
