# Commandrra AI 🖥️

تطبيق موبايل (Flutter) لمساعد ذكاء اصطناعي يجمع بين **الدردشة** (بحال ChatGPT)، **البحث بمصادر** (بحال Perplexity)، و**البرمجة** (بحال Opus) — مبني حول نموذج وهمي اسمه **commandrra 2.1**.

هاد النسخة كاملة الوظائف (UI + state management + تدفق كامل) وكتخدم بـ **بيانات تجريبية (mock)** بلا الحاجة لأي API حقيقي، والبنية مصممة باش تربط API حقيقي بسطر واحد فقط.

---

## 1. المتطلبات

- Flutter SDK **3.27 أو أحدث** (بسبب استخدام `Color.withValues` و `Switch.activeThumbColor`)
- Dart SDK **3.5+**
- Android Studio / Xcode (حسب المنصة اللي باغي تبني ليها)

تحقق من نسختك:
```bash
flutter --version
```

---

## 2. أول تشغيل

هاد المجلد فيه غير `lib/`، `pubspec.yaml`، و `assets/` — الملفات الأصلية ديال Android/iOS/Web كتتولد تلقائيًا. من جذر المشروع:

```bash
# 1. ولّد ملفات المنصات (android/, ios/, web/...)
flutter create .

# 2. حمّل المكتبات
flutter pub get

# 3. شغّل التطبيق
flutter run
```

> **ملاحظة:** `flutter create .` غادي يزيد ملفات المنصة بلا ما يمس `lib/` ديالك الموجودة.

---

## 3. بنية المشروع

```
lib/
├── main.dart                    # نقطة الانطلاق — تهيئة storage + ProviderScope
├── core/
│   ├── theme/                   # الألوان، الخطوط، الـ ThemeData
│   ├── constants/                # اسم النموذج، حدود التوكنز، أسعار الخطط
│   └── router/                   # go_router — كل المسارات
├── models/                       # ChatMessage, Conversation, Skill, Connector, Plan...
├── services/
│   ├── ai_service.dart           # الـ interface المجردة (نقطة الربط مع API حقيقي)
│   ├── mock_ai_service.dart      # التنفيذ التجريبي الحالي
│   ├── skills_catalog.dart       # كتالوج المهارات المدمجة
│   ├── connectors_catalog.dart   # كتالوج الموصلات المدمجة
│   └── storage_service.dart      # تخزين محلي (SharedPreferences)
├── providers/                    # Riverpod — إدارة الحالة الكاملة
├── screens/                      # كل شاشة (chat, skills, connectors, plans, settings, onboarding)
└── widgets/                      # مكونات قابلة لإعادة الاستخدام (composer, bubbles, mode selector...)
```

---

## 4. كيفاش نربط API حقيقي (commandrra 2.1)

كل التطبيق كيهدر مع الذكاء الاصطناعي عبر واجهة واحدة مجردة: `AiService` (فـ `lib/services/ai_service.dart`). التنفيذ الحالي (`MockAiService`) كيحاكي streaming وكيرجع ردود جاهزة.

### الخطوات:

**أ. أنشئ تنفيذ جديد**، مثلا `lib/services/commandrra_api_service.dart`:

```dart
import 'ai_service.dart';
import '../models/enums.dart';
import '../models/message.dart';

class CommandrraApiService implements AiService {
  final String baseUrl;
  final String apiKey;

  CommandrraApiService({required this.baseUrl, required this.apiKey});

  @override
  Stream<String> sendMessage({
    required String prompt,
    required AssistantMode mode,
    required List<ChatMessage> history,
    List<Attachment> attachments = const [],
    String? activeSkillId,
  }) async* {
    // مثال: اتصال SSE أو WebSocket مع commandrra 2.1
    // افتح الاتصال، وكل ما توصل chunk من النص:
    //   yield chunk;
  }

  @override
  Future<List<SourceRef>> fetchSources(String query) async {
    // نداء REST لجلب نتائج البحث الحقيقية
    return [];
  }

  @override
  int estimateTokens(String text) {
    // إما تقدير محلي، أو رجع القيمة الحقيقية من رد الـ API
    return (text.length / 4).ceil();
  }
}
```

**ب. بدّل سطر واحد** فـ `lib/providers/ai_service_provider.dart`:

```dart
final aiServiceProvider = Provider<AiService>((ref) {
  return CommandrraApiService(
    baseUrl: 'https://api.commandrra.ai/v1',
    apiKey: 'YOUR_KEY', // الأفضل: من متغير بيئة أو secure storage
  );
});
```

**هذا كافٍ.** ما من حاجة لتغيير أي شاشة أو widget — كلها كتستهلك `AiService` عبر الـ interface.

### أمن المفاتيح
لا تكتب أبدًا الـ API key مباشرة فالكود المرفوع لـ Git. استعمل:
- [`flutter_dotenv`](https://pub.dev/packages/flutter_dotenv) لمتغيرات البيئة، أو
- طلب المفتاح عبر backend وسيط (توصية أقوى للإنتاج) بدل تخزينه فالتطبيق مباشرة.

---

## 5. نظام التوكنز والخطط

الحدود معرّفة فـ `lib/core/constants/app_constants.dart` (class `PlanLimits`):

```dart
static const int freeMonthlyTokens = 50000;
static const int proMonthlyTokens = 1000000;
static const int teamMonthlyTokens = 5000000;
```

الاستهلاك الفعلي متتبَّع فـ `UsageNotifier` (`lib/providers/usage_provider.dart`) ومحفوظ محليًا. لربط فوترة حقيقية (Stripe, RevenueCat...):
1. بدّل `changePlan()` باش تنادي مزود الدفع بدل ما تبدل القيمة محليًا مباشرة
2. اجعل `recordUsage()` يزامن مع backend بدل الاعتماد فقط على `estimateTokens()` المحلي

---

## 6. المهارات والموصلات

- **المهارات** (`lib/services/skills_catalog.dart`): كتالوج ثابت حاليًا. فـ الإنتاج، يفضّل يتجاب من API باش يتحدث بلا تحديث التطبيق.
- **الموصلات** (`lib/services/connectors_catalog.dart`): حاليًا محاكاة OAuth (`ConnectorsNotifier.connect()` كتستنى وتبدل الحالة). لربط OAuth حقيقي، استعمل مثلا [`flutter_web_auth_2`](https://pub.dev/packages/flutter_web_auth_2) هنا.

---

## 7. الحزم الرئيسية المستعملة

| الحزمة | الاستخدام |
|---|---|
| `flutter_riverpod` | إدارة الحالة |
| `go_router` | التنقل |
| `flutter_markdown` + `flutter_highlight` | عرض الردود + تلوين الكود |
| `image_picker` / `file_picker` | تحليل الصور والملفات |
| `shared_preferences` | تخزين محلي خفيف |
| `dio` | جاهزة لنداءات HTTP الحقيقية |
| `google_fonts` | خطوط Inter + JetBrains Mono |

---

## 8. الهوية البصرية

- **الخلفية:** Deep Ink (`#0B0E14`)
- **اللون المميز الأساسي:** Amber (`#FFB454`) — صوت المساعد
- **البحث/البرمجة:** Cyan (`#4FD1C5`) / Purple (`#8B5CF6`)
- **العنصر المميز:** شريط أوامر (Command Bar) يتبدل شكله ولونه حسب الوضع (دردشة/بحث/برمجة) — تجده فـ `lib/widgets/common/mode_selector.dart`

---

## 9. خطوات مقترحة بعد هاد النسخة

- [ ] ربط API حقيقي (انظر القسم 4)
- [ ] إضافة مصادقة (Firebase Auth / Supabase / Auth0)
- [ ] ربط مزود دفع حقيقي للخطط المدفوعة
- [ ] OAuth حقيقي للموصلات
- [ ] رفع الملفات الفعلي لتحليل الصور (حاليًا كيوصل الـ path فقط للـ mock)
- [ ] إشعارات push

---

صُنع بـ Flutter 💙
